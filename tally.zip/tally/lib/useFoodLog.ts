"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { DEMO_DAY } from "@/lib/demo";
import type { AnalyzedFood, FoodEntry } from "@/types/nutrition";

const STORAGE_KEY = "tally:entries:v1";

export function localDateKey(date: Date = new Date()): string {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

export function useFoodLog() {
  const [entries, setEntries] = useState<FoodEntry[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setEntries(JSON.parse(raw) as FoodEntry[]);
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
    } catch {
      return;
    }
  }, [entries, ready]);

  const addFoods = useCallback((foods: AnalyzedFood[]) => {
    const now = new Date();
    setEntries((previous) => [
      ...previous,
      ...foods.map((food, index) => ({
        ...food,
        id: crypto.randomUUID(),
        date: localDateKey(now),
        loggedAt: new Date(now.getTime() + index).toISOString(),
      })),
    ]);
  }, []);

  const removeEntry = useCallback((id: string) => {
    setEntries((previous) => previous.filter((entry) => entry.id !== id));
  }, []);

  const loadDemo = useCallback(() => {
    const today = localDateKey();
    setEntries((previous) => [
      ...previous.filter((entry) => entry.date !== today),
      ...DEMO_DAY.map(({ time, food }) => {
        const [hours, minutes] = time.split(":").map(Number);
        const at = new Date();
        at.setHours(hours, minutes, 0, 0);
        return { ...food, id: crypto.randomUUID(), date: today, loggedAt: at.toISOString() };
      }),
    ]);
  }, []);

  const clearToday = useCallback(() => {
    const today = localDateKey();
    setEntries((previous) => previous.filter((entry) => entry.date !== today));
  }, []);

  const todaysEntries = useMemo(() => {
    const today = localDateKey();
    return entries
      .filter((entry) => entry.date === today)
      .sort((a, b) => a.loggedAt.localeCompare(b.loggedAt));
  }, [entries]);

  return { todaysEntries, ready, addFoods, removeEntry, loadDemo, clearToday };
}
