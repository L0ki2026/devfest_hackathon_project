import { AppError } from "@/lib/errors";
import { round } from "@/lib/nutrition";
import type { Nutrition, ProductCandidate } from "@/types/nutrition";

const USDA_BASE = "https://api.nal.usda.gov/fdc/v1";
const OFF_BASE = "https://world.openfoodfacts.org";
const OFF_HEADERS = { "User-Agent": "Tally/1.0 (nutrition tracker demo)" };
const OFF_FIELDS =
  "code,product_name,brands,ingredients_text,ingredients_text_en,nutriments,serving_size,serving_quantity,image_front_small_url";
const TIMEOUT_MS = 12000;

async function fetchJson<T>(url: string, label: string, init: RequestInit = {}): Promise<T | null> {
  let response: Response;
  try {
    response = await fetch(url, { ...init, signal: AbortSignal.timeout(TIMEOUT_MS), cache: "no-store" });
  } catch {
    throw new AppError(`${label} is unreachable or took too long to respond. Try again.`, 504);
  }
  if (response.status === 404) return null;
  if (response.status === 429) {
    throw new AppError(`${label} rate limit reached. Wait a moment, or use your own API key.`, 429);
  }
  if (!response.ok) {
    throw new AppError(`${label} returned an error (${response.status}).`, 502);
  }
  try {
    return (await response.json()) as T;
  } catch {
    throw new AppError(`${label} returned an unreadable response.`, 502);
  }
}

interface UsdaNutrient {
  nutrientId?: number;
  value?: number;
}

interface UsdaFood {
  fdcId: number;
  description: string;
  foodNutrients?: UsdaNutrient[];
}

const USDA_IDS = {
  calories: [1008, 2047, 2048],
  protein: [1003],
  carbs: [1005],
  fat: [1004],
  fiber: [1079],
  iron: [1089],
  calcium: [1087],
  potassium: [1092],
  magnesium: [1090],
  vitaminD: [1114],
  vitaminC: [1162],
  sodium: [1093],
} as const;

function pick(nutrients: UsdaNutrient[], ids: readonly number[]): number {
  for (const id of ids) {
    const match = nutrients.find((nutrient) => nutrient.nutrientId === id);
    if (match && typeof match.value === "number") return match.value;
  }
  return 0;
}

export interface UsdaMatch {
  fdcId: number;
  description: string;
  nutrition: Nutrition;
}

export async function searchUsda(query: string, grams: number): Promise<UsdaMatch | null> {
  const apiKey = process.env.USDA_API_KEY;
  if (!apiKey) throw new AppError("USDA_API_KEY is not set. Add it to .env.local.", 500);

  for (const dataType of ["Foundation,SR Legacy", "Survey (FNDDS)"]) {
    const params = new URLSearchParams({ query, dataType, pageSize: "5", api_key: apiKey });
    const data = await fetchJson<{ foods?: UsdaFood[] }>(
      `${USDA_BASE}/foods/search?${params}`,
      "USDA FoodData Central",
    );
    const food = data?.foods?.find((item) => pick(item.foodNutrients ?? [], USDA_IDS.calories) > 0);
    if (!food) continue;

    const nutrients = food.foodNutrients ?? [];
    const scale = (ids: readonly number[]): number => round((pick(nutrients, ids) * grams) / 100, 1);
    return {
      fdcId: food.fdcId,
      description: food.description,
      nutrition: {
        macros: {
          calories: scale(USDA_IDS.calories),
          protein: scale(USDA_IDS.protein),
          carbs: scale(USDA_IDS.carbs),
          fat: scale(USDA_IDS.fat),
          fiber: scale(USDA_IDS.fiber),
        },
        micros: {
          iron: scale(USDA_IDS.iron),
          calcium: scale(USDA_IDS.calcium),
          potassium: scale(USDA_IDS.potassium),
          magnesium: scale(USDA_IDS.magnesium),
          vitaminD: scale(USDA_IDS.vitaminD),
          vitaminC: scale(USDA_IDS.vitaminC),
          sodium: scale(USDA_IDS.sodium),
        },
      },
    };
  }
  return null;
}

interface OffProduct {
  code?: string;
  product_name?: string;
  brands?: string;
  ingredients_text?: string;
  ingredients_text_en?: string;
  nutriments?: Record<string, number | string | undefined>;
  serving_size?: string;
  serving_quantity?: number | string;
  image_front_small_url?: string;
}

export interface PackagedProduct {
  barcode: string;
  name: string;
  brand?: string;
  imageUrl?: string;
  servingLabel: string;
  ingredientsText: string;
  perServing: Nutrition;
}

function toPackagedProduct(barcode: string, product: OffProduct): PackagedProduct {
  const nutriments = product.nutriments ?? {};
  const per100 = (key: string): number => {
    const value = Number(nutriments[`${key}_100g`]);
    return Number.isFinite(value) ? value : 0;
  };

  const servingQuantity = Number(product.serving_quantity);
  const hasServing = Number.isFinite(servingQuantity) && servingQuantity > 0;
  const servingGrams = hasServing ? servingQuantity : 100;
  const factor = servingGrams / 100;
  const perServing = (amount: number, multiplier = 1): number => round(amount * factor * multiplier, 1);

  const kcal = per100("energy-kcal") || per100("energy") / 4.184;
  const sodiumGrams = per100("sodium") || per100("salt") / 2.5;

  return {
    barcode,
    name: product.product_name?.trim() || "Unnamed product",
    brand: product.brands?.split(",")[0]?.trim() || undefined,
    imageUrl: product.image_front_small_url || undefined,
    servingLabel: hasServing ? product.serving_size?.trim() || `${servingGrams} g` : "100 g",
    ingredientsText: (product.ingredients_text_en || product.ingredients_text || "").trim(),
    perServing: {
      macros: {
        calories: perServing(kcal),
        protein: perServing(per100("proteins")),
        carbs: perServing(per100("carbohydrates")),
        fat: perServing(per100("fat")),
        fiber: perServing(per100("fiber")),
      },
      micros: {
        iron: perServing(per100("iron"), 1000),
        calcium: perServing(per100("calcium"), 1000),
        potassium: perServing(per100("potassium"), 1000),
        magnesium: perServing(per100("magnesium"), 1000),
        vitaminD: perServing(per100("vitamin-d"), 1_000_000),
        vitaminC: perServing(per100("vitamin-c"), 1000),
        sodium: perServing(sodiumGrams, 1000),
      },
    },
  };
}

export async function fetchOffProduct(barcode: string): Promise<PackagedProduct> {
  const codes = barcode.length === 12 ? [barcode, `0${barcode}`] : [barcode];
  for (const code of codes) {
    const params = new URLSearchParams({ fields: OFF_FIELDS });
    const data = await fetchJson<{ status?: number; product?: OffProduct }>(
      `${OFF_BASE}/api/v2/product/${code}.json?${params}`,
      "Open Food Facts",
      { headers: OFF_HEADERS },
    );
    if (data?.status === 1 && data.product) return toPackagedProduct(code, data.product);
  }
  throw new AppError(
    `No product with barcode ${barcode} was found in Open Food Facts. Try searching by name or scan its label.`,
    404,
  );
}

export async function searchOffProducts(query: string): Promise<ProductCandidate[]> {
  const params = new URLSearchParams({
    search_terms: query,
    search_simple: "1",
    action: "process",
    json: "1",
    page_size: "8",
    fields: "code,product_name,brands,image_front_small_url",
  });
  const data = await fetchJson<{ products?: OffProduct[] }>(
    `${OFF_BASE}/cgi/search.pl?${params}`,
    "Open Food Facts",
    { headers: OFF_HEADERS },
  );

  const candidates: ProductCandidate[] = [];
  for (const product of data?.products ?? []) {
    if (!product.code || !product.product_name?.trim()) continue;
    candidates.push({
      barcode: product.code,
      name: product.product_name.trim(),
      brand: product.brands?.split(",")[0]?.trim() || undefined,
      imageUrl: product.image_front_small_url || undefined,
    });
  }
  if (candidates.length === 0) {
    throw new AppError(`No packaged products matched "${query}". Try fewer words or scan the label.`, 404);
  }
  return candidates;
}
