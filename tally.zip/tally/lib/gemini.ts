import { GoogleGenAI, Type, type Part, type Schema } from "@google/genai";
import { AppError } from "@/lib/errors";
import { round } from "@/lib/nutrition";
import { finalizeAnalysis, parseIngredients } from "@/lib/scoring";
import type {
  IngredientAnalysis,
  IngredientAssessment,
  IngredientCategory,
  IngredientFlag,
  Nutrition,
} from "@/types/nutrition";

const MODEL = "gemini-2.5-flash";

const NUTRITION_KEYS = [
  "calories",
  "proteinG",
  "carbsG",
  "fatG",
  "fiberG",
  "ironMg",
  "calciumMg",
  "potassiumMg",
  "magnesiumMg",
  "vitaminDMcg",
  "vitaminCMg",
  "sodiumMg",
] as const;

export type RawNutrition = Record<(typeof NUTRITION_KEYS)[number], number>;

export interface ParsedMealItem {
  name: string;
  quantityLabel: string;
  grams: number;
  usdaQuery: string;
  estimate: RawNutrition;
}

export interface ImageExtraction {
  kind: "meal" | "label" | "unknown";
  productName: string;
  brand: string;
  servingLabel: string;
  ingredientsText: string;
  labelNutrition: RawNutrition;
  mealItems: ParsedMealItem[];
}

interface IngredientScoreResult {
  qualityScore: number;
  summary: string;
  ingredients: IngredientAssessment[];
}

const CATEGORIES: IngredientCategory[] = [
  "whole_food",
  "whole_grain",
  "healthy_fat",
  "neutral",
  "refined_ingredient",
  "added_sugar",
  "artificial_dye",
  "artificial_sweetener",
  "preservative",
  "hydrogenated_oil",
  "high_fructose_corn_syrup",
  "ultra_processed_additive",
];

const FLAGS: IngredientFlag[] = ["clean", "neutral", "watchout"];

const text = (): Schema => ({ type: Type.STRING });
const num = (): Schema => ({ type: Type.NUMBER });

export const nutritionSchema: Schema = {
  type: Type.OBJECT,
  properties: Object.fromEntries(NUTRITION_KEYS.map((key) => [key, num()])),
  required: [...NUTRITION_KEYS],
};

const foodItemSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    name: text(),
    quantityLabel: text(),
    grams: num(),
    usdaQuery: text(),
    estimate: nutritionSchema,
  },
  required: ["name", "quantityLabel", "grams", "usdaQuery", "estimate"],
};

export const mealParseSchema: Schema = {
  type: Type.OBJECT,
  properties: { items: { type: Type.ARRAY, items: foodItemSchema } },
  required: ["items"],
};

export const ingredientScoreSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    qualityScore: num(),
    summary: text(),
    ingredients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: text(),
          category: { type: Type.STRING, enum: CATEGORIES },
          flag: { type: Type.STRING, enum: FLAGS },
          reason: text(),
        },
        required: ["name", "category", "flag", "reason"],
      },
    },
  },
  required: ["qualityScore", "summary", "ingredients"],
};

export const imageExtractionSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    kind: { type: Type.STRING, enum: ["meal", "label", "unknown"] },
    productName: text(),
    brand: text(),
    servingLabel: text(),
    ingredientsText: text(),
    labelNutrition: nutritionSchema,
    mealItems: { type: Type.ARRAY, items: foodItemSchema },
  },
  required: [
    "kind",
    "productName",
    "brand",
    "servingLabel",
    "ingredientsText",
    "labelNutrition",
    "mealItems",
  ],
};

const MEAL_INSTRUCTION = `You convert meal descriptions into individual foods for a nutrition tracker.
Split combined meals into separate items. For each item return:
- name: short display name
- quantityLabel: the portion as the person would say it, such as "2 large eggs"
- grams: your best estimate of the total edible weight of the portion in grams
- usdaQuery: a short generic USDA FoodData Central search phrase with the food and its preparation, such as "egg whole cooked hard-boiled" or "bread sourdough". Never include brand names.
- estimate: the nutrition of the whole portion (not per 100 g). Units: calories in kcal, grams for protein, carbs, fat and fiber, milligrams for iron, calcium, potassium, magnesium, vitamin C and sodium, micrograms for vitamin D.
Use standard serving sizes when a quantity is vague. Skip plain water.`;

const IMAGE_INSTRUCTION = `You read photos for a nutrition tracker.
If the photo shows a meal or food, set kind to "meal" and list every visible food in mealItems using these rules: name, quantityLabel, grams (estimated edible weight of the portion), usdaQuery (short generic USDA search phrase, no brands), and estimate (nutrition of the whole portion; kcal for calories, grams for protein, carbs, fat and fiber, milligrams for iron, calcium, potassium, magnesium, vitamin C and sodium, micrograms for vitamin D). Leave ingredientsText empty and zero out labelNutrition.
If the photo shows a packaged food's Nutrition Facts panel and/or ingredient list, set kind to "label". Transcribe productName and brand if visible (empty string otherwise), servingLabel as printed, ingredientsText exactly as printed (empty string if the ingredient list is not visible), and labelNutrition per serving as printed, using 0 for nutrients that are not listed. Return an empty mealItems array.
If the photo shows neither, set kind to "unknown".`;

const INGREDIENT_INSTRUCTION = `You grade packaged food ingredient lists for cleanliness.
Return one assessment per ingredient, in the same order as provided, copying each name exactly.
Categories: whole_food, whole_grain, healthy_fat, neutral, refined_ingredient, added_sugar, artificial_dye, artificial_sweetener, preservative, hydrogenated_oil, high_fructose_corn_syrup, ultra_processed_additive.
Flag "clean" for recognizable whole foods, whole grains and healthy fats. Flag "watchout" for ultra-processed additives, artificial dyes, hydrogenated oils, high-fructose corn syrup, artificial sweeteners, refined starches and syrups, flavor enhancers and questionable preservatives. Flag "neutral" for everything benign or unremarkable, such as salt, spices, simple oils and natural flavors.
reason: at most 12 words.
qualityScore (0-100) judges ingredient quality only, ignoring how many ingredients there are: 90-100 all whole or minimally processed; 70-89 mostly whole with a few benign refined items; 40-69 refined ingredients, added sugars or a few additives; below 40 dominated by ultra-processed additives, artificial dyes, hydrogenated oils, HFCS or artificial sweeteners.
summary: two sentences at most explaining the grade in plain language.`;

let client: GoogleGenAI | null = null;

function getClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new AppError("GEMINI_API_KEY is not set. Add it to .env.local and restart the dev server.", 500);
  }
  client ??= new GoogleGenAI({ apiKey });
  return client;
}

async function generateJson<T>(parts: Part[], schema: Schema, systemInstruction: string): Promise<T> {
  try {
    const response = await getClient().models.generateContent({
      model: MODEL,
      contents: [{ role: "user", parts }],
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: 0.2,
        thinkingConfig: { thinkingBudget: 0 },
      },
    });
    const output = response.text;
    if (!output) throw new AppError("Gemini returned an empty response. Try again.", 502);
    return JSON.parse(output) as T;
  } catch (error) {
    if (error instanceof AppError) throw error;
    const detail = error instanceof Error ? error.message : "unknown error";
    throw new AppError(`Gemini request failed: ${detail}`, 502);
  }
}

export function toNutrition(raw: RawNutrition): Nutrition {
  const value = (amount: number): number => round(Number.isFinite(amount) && amount > 0 ? amount : 0, 1);
  return {
    macros: {
      calories: value(raw.calories),
      protein: value(raw.proteinG),
      carbs: value(raw.carbsG),
      fat: value(raw.fatG),
      fiber: value(raw.fiberG),
    },
    micros: {
      iron: value(raw.ironMg),
      calcium: value(raw.calciumMg),
      potassium: value(raw.potassiumMg),
      magnesium: value(raw.magnesiumMg),
      vitaminD: value(raw.vitaminDMcg),
      vitaminC: value(raw.vitaminCMg),
      sodium: value(raw.sodiumMg),
    },
  };
}

export async function parseMeal(description: string): Promise<ParsedMealItem[]> {
  const result = await generateJson<{ items: ParsedMealItem[] }>(
    [{ text: description }],
    mealParseSchema,
    MEAL_INSTRUCTION,
  );
  if (!result.items?.length) {
    throw new AppError("No foods were found in that description. Try listing what you ate with quantities.", 422);
  }
  return result.items;
}

export async function extractFromImage(imageBase64: string, mimeType: string): Promise<ImageExtraction> {
  return generateJson<ImageExtraction>(
    [{ inlineData: { mimeType, data: imageBase64 } }, { text: "Analyze this photo." }],
    imageExtractionSchema,
    IMAGE_INSTRUCTION,
  );
}

export async function scoreIngredients(rawText: string, productName: string): Promise<IngredientAnalysis> {
  const names = parseIngredients(rawText);
  if (names.length === 0) {
    throw new AppError("The ingredient list could not be read.", 422);
  }
  const result = await generateJson<IngredientScoreResult>(
    [{ text: `Product: ${productName}\nIngredients: ${JSON.stringify(names)}` }],
    ingredientScoreSchema,
    INGREDIENT_INSTRUCTION,
  );
  return finalizeAnalysis(rawText, names, result.ingredients ?? [], result.qualityScore, result.summary);
}
