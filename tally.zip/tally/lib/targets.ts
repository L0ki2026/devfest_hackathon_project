import type { Macros, Micros } from "@/types/nutrition";

export interface Target<K extends string> {
  key: K;
  label: string;
  unit: string;
  goal: number;
  isLimit?: boolean;
}

export const MACRO_TARGETS: Target<keyof Macros>[] = [
  { key: "calories", label: "Calories", unit: "kcal", goal: 2000 },
  { key: "protein", label: "Protein", unit: "g", goal: 50 },
  { key: "carbs", label: "Carbs", unit: "g", goal: 275 },
  { key: "fat", label: "Fat", unit: "g", goal: 78 },
  { key: "fiber", label: "Fiber", unit: "g", goal: 28 },
];

export const MICRO_TARGETS: Target<keyof Micros>[] = [
  { key: "iron", label: "Iron", unit: "mg", goal: 18 },
  { key: "potassium", label: "Potassium", unit: "mg", goal: 4700 },
  { key: "calcium", label: "Calcium", unit: "mg", goal: 1300 },
  { key: "magnesium", label: "Magnesium", unit: "mg", goal: 420 },
  { key: "vitaminD", label: "Vitamin D", unit: "mcg", goal: 20 },
  { key: "vitaminC", label: "Vitamin C", unit: "mg", goal: 90 },
  { key: "sodium", label: "Sodium", unit: "mg", goal: 2300, isLimit: true },
];
