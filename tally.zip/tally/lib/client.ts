import type { AnalyzeRequest, AnalyzeResponse } from "@/types/nutrition";

export async function requestAnalysis(body: AnalyzeRequest): Promise<AnalyzeResponse> {
  let response: Response;
  try {
    response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error("Could not reach the server. Check your connection and try again.");
  }

  const payload: unknown = await response.json().catch(() => null);
  if (!response.ok) {
    const message =
      payload && typeof payload === "object" && "error" in payload ? String((payload as { error: unknown }).error) : "";
    throw new Error(message || `Request failed (${response.status}).`);
  }
  return payload as AnalyzeResponse;
}
