import type { Grade, IngredientAnalysis, IngredientAssessment } from "@/types/nutrition";

export const QUALITY_WEIGHT = 0.65;
export const COUNT_WEIGHT = 0.35;

export function parseIngredients(raw: string): string[] {
  const text = raw
    .replace(/\s+/g, " ")
    .replace(/^\s*ingredients?\s*[:\-]\s*/i, "")
    .replace(/contains?\s+(?:less than\s+)?\d+(?:\.\d+)?%\s+or\s+less\s+of\s*:?/gi, ",")
    .replace(/(?:contains?\s+)?(?:less than|<)\s*\d+(?:\.\d+)?%\s+of\s*:?/gi, ",")
    .replace(/\bcontains\s*:.*$/i, "")
    .replace(/\bmay contain\b.*$/i, "");

  const parts: string[] = [];
  let depth = 0;
  let current = "";
  for (const char of text) {
    if ("([{".includes(char)) depth += 1;
    else if (")]}".includes(char)) depth = Math.max(0, depth - 1);
    if ((char === "," || char === ";") && depth === 0) {
      parts.push(current);
      current = "";
      continue;
    }
    current += char;
  }
  parts.push(current);

  return parts
    .map((part) => part.trim().replace(/^[.\s*]+|[.\s*]+$/g, ""))
    .filter((part) => part.length > 0);
}

export function countScore(count: number): number {
  if (count <= 5) return 100;
  if (count <= 10) return 100 - (count - 5) * 4;
  if (count <= 20) return 80 - (count - 10) * 3;
  if (count <= 35) return 50 - (count - 20) * 2;
  return Math.max(0, 20 - (count - 35));
}

export function gradeFor(score: number): Grade {
  if (score >= 90) return "A";
  if (score >= 75) return "B";
  if (score >= 60) return "C";
  if (score >= 45) return "D";
  return "F";
}

const normalize = (value: string): string => value.toLowerCase().replace(/\s+/g, " ").trim();
const clamp = (value: number): number => Math.min(100, Math.max(0, Math.round(value)));

export function finalizeAnalysis(
  rawText: string,
  names: string[],
  returned: IngredientAssessment[],
  qualityScore: number,
  summary: string,
): IngredientAnalysis {
  const lookup = new Map(returned.map((item) => [normalize(item.name), item]));
  const ingredients: IngredientAssessment[] = names.map((name, index) => {
    const match =
      lookup.get(normalize(name)) ?? (returned.length === names.length ? returned[index] : undefined);
    return {
      name,
      category: match?.category ?? "neutral",
      flag: match?.flag ?? "neutral",
      reason: match?.reason ?? "",
    };
  });

  const quality = clamp(qualityScore);
  const count = clamp(countScore(names.length));
  const cleanScore = clamp(quality * QUALITY_WEIGHT + count * COUNT_WEIGHT);

  return {
    ingredientCount: names.length,
    ingredients,
    qualityScore: quality,
    countScore: count,
    cleanScore,
    grade: gradeFor(cleanScore),
    summary,
    rawText,
  };
}
