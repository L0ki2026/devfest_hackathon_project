import { finalizeAnalysis, parseIngredients } from "@/lib/scoring";
import type {
  AnalyzedFood,
  IngredientCategory,
  IngredientFlag,
  Nutrition,
} from "@/types/nutrition";

type Macros5 = [number, number, number, number, number];
type Micros7 = [number, number, number, number, number, number, number];
type Spec = [IngredientCategory, IngredientFlag, string];

function nutrition(macros: Macros5, micros: Micros7): Nutrition {
  return {
    macros: { calories: macros[0], protein: macros[1], carbs: macros[2], fat: macros[3], fiber: macros[4] },
    micros: {
      iron: micros[0],
      calcium: micros[1],
      potassium: micros[2],
      magnesium: micros[3],
      vitaminD: micros[4],
      vitaminC: micros[5],
      sodium: micros[6],
    },
  };
}

function whole(name: string, quantityLabel: string, matchedName: string, values: Nutrition): AnalyzedFood {
  return { name, quantityLabel, matchedName, kind: "whole", source: "usda", ...values };
}

function packaged(
  name: string,
  brand: string,
  quantityLabel: string,
  values: Nutrition,
  ingredientsText: string,
  specs: Spec[],
  qualityScore: number,
  summary: string,
): AnalyzedFood {
  const names = parseIngredients(ingredientsText);
  const assessments = names.map((ingredient, index) => ({
    name: ingredient,
    category: specs[index][0],
    flag: specs[index][1],
    reason: specs[index][2],
  }));
  return {
    name,
    brand,
    quantityLabel,
    kind: "packaged",
    source: "openfoodfacts",
    ...values,
    ingredientAnalysis: finalizeAnalysis(ingredientsText, names, assessments, qualityScore, summary),
  };
}

const GRANOLA_TEXT =
  "Whole grain rolled oats, almonds, honey, brown rice syrup, sunflower oil, sea salt, natural vanilla flavor, mixed tocopherols";

const GRANOLA_SPECS: Spec[] = [
  ["whole_grain", "clean", "Intact whole grain with fiber."],
  ["healthy_fat", "clean", "Whole nut with healthy fats and protein."],
  ["added_sugar", "neutral", "Natural sweetener, but still added sugar."],
  ["added_sugar", "watchout", "Refined syrup that raises blood sugar quickly."],
  ["neutral", "neutral", "Plain oil used as a binder."],
  ["neutral", "neutral", "Seasoning in a small amount."],
  ["neutral", "neutral", "Natural flavoring in a small amount."],
  ["preservative", "neutral", "Vitamin E that keeps oils fresh."],
];

const PUFFS_TEXT =
  "Enriched cornmeal (corn meal, ferrous sulfate, niacin, thiamin mononitrate, riboflavin, folic acid), vegetable oil (corn, canola, and/or sunflower oil), whey, cheddar cheese (milk, cheese cultures, salt, enzymes), natural and artificial flavors, salt, maltodextrin, monosodium glutamate, yellow 6, yellow 5, red 40, citric acid, sodium diacetate, lactic acid, disodium inosinate, disodium guanylate, soy lecithin";

const PUFFS_SPECS: Spec[] = [
  ["refined_ingredient", "watchout", "Refined corn flour with synthetic nutrients added back."],
  ["neutral", "neutral", "Generic oil blend, high in omega-6."],
  ["neutral", "neutral", "Dairy protein."],
  ["neutral", "neutral", "Real cheese, though a small share."],
  ["ultra_processed_additive", "watchout", "Undisclosed flavor compounds."],
  ["neutral", "neutral", "Seasoning."],
  ["ultra_processed_additive", "watchout", "Highly processed starch that raises blood sugar fast."],
  ["ultra_processed_additive", "watchout", "Flavor enhancer common in ultra-processed snacks."],
  ["artificial_dye", "watchout", "Synthetic petroleum-derived dye."],
  ["artificial_dye", "watchout", "Synthetic petroleum-derived dye."],
  ["artificial_dye", "watchout", "Synthetic dye linked to hyperactivity concerns."],
  ["preservative", "neutral", "Common acidulant, generally benign."],
  ["preservative", "watchout", "Synthetic preservative and flavoring."],
  ["neutral", "neutral", "Natural acid used for tang."],
  ["ultra_processed_additive", "watchout", "Flavor enhancer paired with MSG."],
  ["ultra_processed_additive", "watchout", "Flavor enhancer paired with MSG."],
  ["neutral", "neutral", "Emulsifier from soybeans."],
];

const ALMOND_TEXT = "Dry roasted almonds, sea salt";

const ALMOND_SPECS: Spec[] = [
  ["healthy_fat", "clean", "Whole food, rich in healthy fats."],
  ["neutral", "neutral", "Seasoning."],
];

export const DEMO_DAY: { time: string; food: AnalyzedFood }[] = [
  {
    time: "07:45",
    food: whole("Hard-boiled eggs", "2 large eggs (~100 g)", "Egg, whole, cooked, hard-boiled",
      nutrition([155, 12.6, 1.1, 10.6, 0], [1.2, 50, 126, 10, 2.2, 0, 124])),
  },
  {
    time: "07:46",
    food: whole("Sourdough toast", "1 slice (~45 g)", "Bread, sourdough",
      nutrition([130, 5.2, 25, 0.8, 1.2], [1.4, 22, 50, 12, 0, 0, 270])),
  },
  {
    time: "07:47",
    food: whole("Avocado", "Half an avocado (~100 g)", "Avocados, raw, all commercial varieties",
      nutrition([160, 2, 8.5, 14.7, 6.7], [0.6, 12, 485, 29, 0, 10, 7])),
  },
  {
    time: "10:30",
    food: packaged("Honey Almond Granola Bar", "Meadowline", "1 serving (1 bar, 40 g)",
      nutrition([180, 4, 26, 7, 3], [1.1, 20, 140, 40, 0, 0, 85]),
      GRANOLA_TEXT, GRANOLA_SPECS, 80,
      "A short list built on oats and almonds. Two added sweeteners keep it from the top grade."),
  },
  {
    time: "12:40",
    food: whole("Grilled chicken breast", "5 oz (~140 g)", "Chicken, broilers or fryers, breast, cooked, roasted",
      nutrition([231, 43.5, 0, 5, 0], [1, 20, 430, 38, 0.2, 0, 104])),
  },
  {
    time: "12:41",
    food: whole("Brown rice", "1 cup cooked (~195 g)", "Rice, brown, long-grain, cooked",
      nutrition([216, 5, 45, 1.8, 3.5], [0.8, 20, 84, 84, 0, 0, 10])),
  },
  {
    time: "15:30",
    food: packaged("Cheddar Cheese Puffs", "Zingo", "1 serving (1 oz, 28 g)",
      nutrition([160, 2, 15, 10, 1], [0.3, 20, 40, 10, 0, 0, 290]),
      PUFFS_TEXT, PUFFS_SPECS, 18,
      "A long list built on refined corn, flavor enhancers and three artificial dyes."),
  },
  {
    time: "16:15",
    food: packaged("Almond Butter", "Meadowline", "1 serving (2 tbsp, 32 g)",
      nutrition([196, 7, 6, 17, 3.3], [1, 90, 210, 90, 0, 0, 55]),
      ALMOND_TEXT, ALMOND_SPECS, 96,
      "Just almonds and salt."),
  },
  {
    time: "19:15",
    food: whole("Baked salmon", "5 oz (~150 g)", "Fish, salmon, Atlantic, farmed, cooked",
      nutrition([312, 33, 0, 19, 0], [0.8, 20, 560, 40, 16, 0, 100])),
  },
  {
    time: "19:16",
    food: whole("Steamed broccoli", "1 cup (~156 g)", "Broccoli, cooked, boiled, drained",
      nutrition([55, 3.7, 11, 0.6, 5.1], [1, 62, 457, 33, 0, 101, 64])),
  },
];
