import type { AnalyzedFood, Macros, Micros, Nutrition } from "@/types/nutrition";

export const emptyMacros = (): Macros => ({ calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 });

export const emptyMicros = (): Micros => ({
  iron: 0,
  calcium: 0,
  potassium: 0,
  magnesium: 0,
  vitaminD: 0,
  vitaminC: 0,
  sodium: 0,
});

export function round(value: number, digits = 1): number {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function scaleValues<T extends Macros | Micros>(values: T, factor: number): T {
  const result = { ...values };
  for (const key of Object.keys(result) as (keyof T)[]) {
    result[key] = round(Number(values[key]) * factor, 2) as T[keyof T];
  }
  return result;
}

export function scaleFood(food: AnalyzedFood, factor: number): AnalyzedFood {
  if (factor === 1) return food;
  return {
    ...food,
    quantityLabel: `${factor} × ${food.quantityLabel}`,
    macros: scaleValues(food.macros, factor),
    micros: scaleValues(food.micros, factor),
  };
}

export function sumNutrition(items: Nutrition[]): Nutrition {
  const macros = emptyMacros();
  const micros = emptyMicros();
  for (const item of items) {
    for (const key of Object.keys(macros) as (keyof Macros)[]) macros[key] += item.macros[key];
    for (const key of Object.keys(micros) as (keyof Micros)[]) micros[key] += item.micros[key];
  }
  return { macros, micros };
}

export function formatAmount(value: number, unit: string): string {
  const shown = value >= 100 ? Math.round(value) : round(value, 1);
  return `${shown} ${unit}`;
}
