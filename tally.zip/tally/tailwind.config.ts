import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#E9EEEA",
        ink: "#16201B",
        leaf: "#1F6F5C",
        moss: "#6A9A3B",
        saffron: "#D9A020",
        tangerine: "#E4772E",
        ember: "#C23B2A",
        berry: "#3F5FA8",
        plum: "#8A4B7A",
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
