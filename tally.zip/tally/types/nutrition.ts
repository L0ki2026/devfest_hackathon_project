export interface Macros {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
}

export interface Micros {
  iron: number;
  calcium: number;
  potassium: number;
  magnesium: number;
  vitaminD: number;
  vitaminC: number;
  sodium: number;
}

export interface Nutrition {
  macros: Macros;
  micros: Micros;
}

export type FoodKind = "whole" | "packaged";

export type FoodSource = "usda" | "openfoodfacts" | "label-scan" | "ai-estimate";

export type Grade = "A" | "B" | "C" | "D" | "F";

export type IngredientCategory =
  | "whole_food"
  | "whole_grain"
  | "healthy_fat"
  | "neutral"
  | "refined_ingredient"
  | "added_sugar"
  | "artificial_dye"
  | "artificial_sweetener"
  | "preservative"
  | "hydrogenated_oil"
  | "high_fructose_corn_syrup"
  | "ultra_processed_additive";

export type IngredientFlag = "clean" | "neutral" | "watchout";

export interface IngredientAssessment {
  name: string;
  category: IngredientCategory;
  flag: IngredientFlag;
  reason: string;
}

export interface IngredientAnalysis {
  ingredientCount: number;
  ingredients: IngredientAssessment[];
  qualityScore: number;
  countScore: number;
  cleanScore: number;
  grade: Grade;
  summary: string;
  rawText: string;
}

export interface Food extends Nutrition {
  name: string;
  brand?: string;
  quantityLabel: string;
  kind: FoodKind;
  source: FoodSource;
  matchedName?: string;
  imageUrl?: string;
  ingredientAnalysis?: IngredientAnalysis;
}

export type AnalyzedFood = Food;

export interface FoodEntry extends Food {
  id: string;
  date: string;
  loggedAt: string;
}

export interface ProductCandidate {
  barcode: string;
  name: string;
  brand?: string;
  imageUrl?: string;
}

export type AnalyzeRequest =
  | { mode: "meal"; text: string }
  | { mode: "barcode"; barcode: string }
  | { mode: "search"; query: string }
  | { mode: "image"; imageBase64: string; mimeType: string };

export interface AnalyzeResponse {
  foods: AnalyzedFood[];
  candidates: ProductCandidate[];
  warnings: string[];
}
