"use client";

import { Sparkles } from "lucide-react";
import { Dashboard } from "@/components/Dashboard";
import { FoodLogger } from "@/components/FoodLogger";
import { useFoodLog } from "@/lib/useFoodLog";

export default function Page() {
  const { todaysEntries, ready, addFoods, removeEntry, loadDemo, clearToday } = useFoodLog();
  const today = new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:py-12">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">Tally</h1>
          <p className="mt-1 text-ink/70" suppressHydrationWarning>
            {today}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={loadDemo}
            className="inline-flex items-center gap-2 rounded-full bg-ink px-4 py-2 text-sm font-medium text-white hover:bg-ink/85"
          >
            <Sparkles className="h-4 w-4" aria-hidden /> Load demo data
          </button>
          {todaysEntries.length > 0 && (
            <button
              type="button"
              onClick={clearToday}
              className="rounded-full px-4 py-2 text-sm font-medium text-ink/70 ring-1 ring-ink/15 hover:bg-ink/5"
            >
              Clear today
            </button>
          )}
        </div>
      </header>

      <div className="mt-8 grid items-start gap-6 lg:grid-cols-[24rem_minmax(0,1fr)]">
        <div className="lg:sticky lg:top-6">
          <FoodLogger onAdd={addFoods} />
        </div>
        <Dashboard entries={todaysEntries} ready={ready} onRemove={removeEntry} onLoadDemo={loadDemo} />
      </div>
    </main>
  );
}
