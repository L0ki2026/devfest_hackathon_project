import { NextRequest, NextResponse } from "next/server";
import { fetchOffProduct, searchOffProducts, searchUsda, type PackagedProduct } from "@/lib/apis";
import { AppError } from "@/lib/errors";
import {
  extractFromImage,
  parseMeal,
  scoreIngredients,
  toNutrition,
  type ImageExtraction,
  type ParsedMealItem,
} from "@/lib/gemini";
import type {
  AnalyzeRequest,
  AnalyzeResponse,
  AnalyzedFood,
  IngredientAnalysis,
  ProductCandidate,
} from "@/types/nutrition";

export const runtime = "nodejs";
export const maxDuration = 60;

const MAX_IMAGE_CHARS = 8_000_000;
const BARCODE_PATTERN = /^\d{8,14}$/;
const IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);

const describe = (error: unknown): string => (error instanceof Error ? error.message : "unknown error");
const capitalize = (value: string): string => value.charAt(0).toUpperCase() + value.slice(1);

function parseRequest(body: unknown): AnalyzeRequest {
  if (!body || typeof body !== "object") throw new AppError("Request body must be JSON.", 400);
  const input = body as Record<string, unknown>;

  switch (input.mode) {
    case "meal": {
      const text = typeof input.text === "string" ? input.text.trim() : "";
      if (!text) throw new AppError("Describe what you ate first.", 400);
      if (text.length > 1500) throw new AppError("That description is too long. Keep it under 1,500 characters.", 400);
      return { mode: "meal", text };
    }
    case "barcode": {
      const barcode = typeof input.barcode === "string" ? input.barcode.replace(/\s+/g, "") : "";
      if (!BARCODE_PATTERN.test(barcode)) throw new AppError("Enter a barcode with 8 to 14 digits.", 400);
      return { mode: "barcode", barcode };
    }
    case "search": {
      const query = typeof input.query === "string" ? input.query.trim() : "";
      if (query.length < 2) throw new AppError("Enter at least two characters to search.", 400);
      return { mode: "search", query };
    }
    case "image": {
      const imageBase64 = typeof input.imageBase64 === "string" ? input.imageBase64 : "";
      const mimeType = typeof input.mimeType === "string" ? input.mimeType : "";
      if (!imageBase64) throw new AppError("No image was provided.", 400);
      if (imageBase64.length > MAX_IMAGE_CHARS) throw new AppError("That image is too large. Try a smaller photo.", 413);
      if (!IMAGE_TYPES.has(mimeType)) throw new AppError("Use a JPG, PNG or WebP image.", 400);
      return { mode: "image", imageBase64, mimeType };
    }
    default:
      throw new AppError("Unknown request mode.", 400);
  }
}

async function scoreSafely(
  ingredientsText: string,
  name: string,
  warnings: string[],
): Promise<IngredientAnalysis | undefined> {
  if (!ingredientsText.trim()) {
    warnings.push("No ingredient list was found for this food, so it has no clean score. Scan its label to add one.");
    return undefined;
  }
  try {
    return await scoreIngredients(ingredientsText, name);
  } catch (error) {
    warnings.push(`Ingredient scoring failed: ${describe(error)}`);
    return undefined;
  }
}

async function resolveMealItems(items: ParsedMealItem[], warnings: string[]): Promise<AnalyzedFood[]> {
  return Promise.all(
    items.map(async (item): Promise<AnalyzedFood> => {
      const grams = item.grams > 0 ? item.grams : 100;
      const base = {
        name: capitalize(item.name),
        quantityLabel: `${item.quantityLabel} (~${Math.round(grams)} g)`,
        kind: "whole" as const,
      };

      try {
        const match = await searchUsda(item.usdaQuery, grams);
        if (match) {
          return { ...base, source: "usda", matchedName: match.description, ...match.nutrition };
        }
        warnings.push(`No USDA match for "${item.name}". Used an AI estimate instead.`);
      } catch (error) {
        warnings.push(`USDA lookup failed for "${item.name}" (${describe(error)}) Used an AI estimate instead.`);
      }
      return { ...base, source: "ai-estimate", ...toNutrition(item.estimate) };
    }),
  );
}

async function foodFromProduct(product: PackagedProduct, warnings: string[]): Promise<AnalyzedFood> {
  const ingredientAnalysis = await scoreSafely(product.ingredientsText, product.name, warnings);
  return {
    name: product.name,
    brand: product.brand,
    quantityLabel: product.servingLabel === "100 g" ? "100 g" : `1 serving (${product.servingLabel})`,
    kind: "packaged",
    source: "openfoodfacts",
    imageUrl: product.imageUrl,
    ...product.perServing,
    ingredientAnalysis,
  };
}

async function foodFromLabel(extraction: ImageExtraction, warnings: string[]): Promise<AnalyzedFood> {
  const name = extraction.productName.trim() || "Scanned packaged food";
  const ingredientAnalysis = await scoreSafely(extraction.ingredientsText, name, warnings);
  return {
    name,
    brand: extraction.brand.trim() || undefined,
    quantityLabel: extraction.servingLabel.trim() ? `1 serving (${extraction.servingLabel.trim()})` : "1 serving",
    kind: "packaged",
    source: "label-scan",
    ...toNutrition(extraction.labelNutrition),
    ingredientAnalysis,
  };
}

async function handle(request: AnalyzeRequest): Promise<AnalyzeResponse> {
  const warnings: string[] = [];
  let foods: AnalyzedFood[] = [];
  let candidates: ProductCandidate[] = [];

  switch (request.mode) {
    case "meal": {
      foods = await resolveMealItems(await parseMeal(request.text), warnings);
      break;
    }
    case "barcode": {
      foods = [await foodFromProduct(await fetchOffProduct(request.barcode), warnings)];
      break;
    }
    case "search": {
      candidates = await searchOffProducts(request.query);
      break;
    }
    case "image": {
      const extraction = await extractFromImage(request.imageBase64, request.mimeType);
      if (extraction.kind === "meal") {
        if (!extraction.mealItems?.length) throw new AppError("No food was detected in that photo.", 422);
        foods = await resolveMealItems(extraction.mealItems, warnings);
      } else if (extraction.kind === "label") {
        const hasNutrition = extraction.labelNutrition.calories > 0;
        if (!hasNutrition && !extraction.ingredientsText.trim()) {
          throw new AppError("The label in that photo was not readable. Retake it closer and in better light.", 422);
        }
        foods = [await foodFromLabel(extraction, warnings)];
      } else {
        throw new AppError("That photo does not show a meal or a nutrition label. Try another one.", 422);
      }
      break;
    }
  }

  return { foods, candidates, warnings };
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const body: unknown = await req.json().catch(() => null);
    const result = await handle(parseRequest(body));
    return NextResponse.json<AnalyzeResponse>(result);
  } catch (error) {
    if (error instanceof AppError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    return NextResponse.json({ error: `Unexpected server error: ${describe(error)}` }, { status: 500 });
  }
}
