import { Leaf, TriangleAlert } from "lucide-react";
import { COUNT_WEIGHT, QUALITY_WEIGHT } from "@/lib/scoring";
import type { Grade, IngredientAnalysis } from "@/types/nutrition";

const GRADE_STYLES: Record<Grade, string> = {
  A: "bg-leaf text-white",
  B: "bg-moss text-white",
  C: "bg-saffron text-ink",
  D: "bg-tangerine text-white",
  F: "bg-ember text-white",
};

export function GradeBadge({ grade, size = "sm" }: { grade: Grade; size?: "sm" | "lg" }) {
  const sizing = size === "lg" ? "h-20 w-20 rounded-2xl text-5xl" : "h-6 min-w-6 rounded-md px-1.5 text-sm";
  return (
    <span
      aria-label={`Grade ${grade}`}
      className={`inline-flex shrink-0 items-center justify-center font-display font-bold ${GRADE_STYLES[grade]} ${sizing}`}
    >
      {grade}
    </span>
  );
}

function ScoreBar({ label, detail, value }: { label: string; detail: string; value: number }) {
  return (
    <div>
      <div className="flex items-baseline justify-between text-sm">
        <span className="font-medium">{label}</span>
        <span className="text-ink/60">{detail}</span>
      </div>
      <div
        role="progressbar"
        aria-label={label}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={value}
        className="mt-1 h-2 overflow-hidden rounded-full bg-ink/10"
      >
        <div className="h-full rounded-full bg-leaf" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

export function IngredientCard({ analysis }: { analysis: IngredientAnalysis }) {
  const clean = analysis.ingredients.filter((item) => item.flag === "clean");
  const watchouts = analysis.ingredients.filter((item) => item.flag === "watchout");
  const neutral = analysis.ingredients.filter((item) => item.flag === "neutral");

  return (
    <div className="rounded-2xl border border-ink/10 bg-white p-5">
      <div className="flex items-center gap-4">
        <GradeBadge grade={analysis.grade} size="lg" />
        <div>
          <p className="font-display text-3xl font-semibold leading-none">
            {analysis.ingredientCount} {analysis.ingredientCount === 1 ? "Ingredient" : "Ingredients"}
          </p>
          <p className="mt-1.5 text-sm text-ink/70">Clean score {analysis.cleanScore} out of 100</p>
        </div>
      </div>

      <p className="mt-4 max-w-prose text-sm leading-relaxed text-ink/80">{analysis.summary}</p>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <ScoreBar
          label="Ingredient quality"
          detail={`${analysis.qualityScore} · ${Math.round(QUALITY_WEIGHT * 100)}% of score`}
          value={analysis.qualityScore}
        />
        <ScoreBar
          label="List length"
          detail={`${analysis.countScore} · ${Math.round(COUNT_WEIGHT * 100)}% of score`}
          value={analysis.countScore}
        />
      </div>

      {watchouts.length > 0 && (
        <div className="mt-5">
          <h4 className="flex items-center gap-1.5 text-sm font-semibold text-ember">
            <TriangleAlert className="h-4 w-4" aria-hidden /> Additives and watchouts ({watchouts.length})
          </h4>
          <ul className="mt-2 space-y-2">
            {watchouts.map((item, index) => (
              <li key={`${item.name}-${index}`} className="border-l-2 border-ember pl-3 text-sm">
                <span className="font-medium">{item.name}</span>
                {item.reason && <span className="block text-ink/65">{item.reason}</span>}
              </li>
            ))}
          </ul>
        </div>
      )}

      {clean.length > 0 && (
        <div className="mt-5">
          <h4 className="flex items-center gap-1.5 text-sm font-semibold text-leaf">
            <Leaf className="h-4 w-4" aria-hidden /> Clean ingredients ({clean.length})
          </h4>
          <ul className="mt-2 space-y-2">
            {clean.map((item, index) => (
              <li key={`${item.name}-${index}`} className="border-l-2 border-leaf pl-3 text-sm">
                <span className="font-medium">{item.name}</span>
                {item.reason && <span className="block text-ink/65">{item.reason}</span>}
              </li>
            ))}
          </ul>
        </div>
      )}

      {neutral.length > 0 && (
        <details className="mt-5 text-sm">
          <summary className="cursor-pointer font-medium text-ink/70">Everything else ({neutral.length})</summary>
          <p className="mt-2 leading-relaxed text-ink/70">{neutral.map((item) => item.name).join(", ")}</p>
        </details>
      )}
    </div>
  );
}
