"use client";

import { useMemo, useState } from "react";
import { Sparkles, Trash2 } from "lucide-react";
import { GradeBadge, IngredientCard } from "@/components/IngredientCard";
import { formatAmount, sumNutrition } from "@/lib/nutrition";
import { MACRO_TARGETS, MICRO_TARGETS, type Target } from "@/lib/targets";
import type { FoodEntry, FoodSource, Macros } from "@/types/nutrition";

const RING_TONES: Record<string, string> = {
  calories: "text-leaf",
  protein: "text-berry",
  carbs: "text-saffron",
  fat: "text-plum",
};

const SOURCE_LABELS: Record<FoodSource, string> = {
  usda: "USDA FoodData Central",
  openfoodfacts: "Open Food Facts",
  "label-scan": "Label scan",
  "ai-estimate": "AI estimate",
};

function Ring({ target, value }: { target: Target<keyof Macros>; value: number }) {
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  const ratio = Math.min(value / target.goal, 1);

  return (
    <div
      role="progressbar"
      aria-label={target.label}
      aria-valuemin={0}
      aria-valuemax={target.goal}
      aria-valuenow={Math.round(value)}
      className="flex flex-col items-center"
    >
      <div className="relative h-28 w-28">
        <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90" aria-hidden>
          <circle cx="50" cy="50" r={radius} fill="none" strokeWidth="9" className="stroke-ink/10" />
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="none"
            strokeWidth="9"
            strokeLinecap="round"
            stroke="currentColor"
            className={`${RING_TONES[target.key]} transition-[stroke-dashoffset] duration-500`}
            strokeDasharray={circumference}
            strokeDashoffset={circumference * (1 - ratio)}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-2xl font-semibold leading-none">{Math.round(value)}</span>
          <span className="mt-0.5 text-xs text-ink/60">of {target.goal} {target.unit}</span>
        </div>
      </div>
      <span className="mt-2 text-sm font-medium">{target.label}</span>
    </div>
  );
}

function Meter({ target, value }: { target: Target<string>; value: number }) {
  const percent = Math.round((value / target.goal) * 100);
  const over = target.isLimit && value > target.goal;

  return (
    <div>
      <div className="flex items-baseline justify-between text-sm">
        <span className="font-medium">{target.label}</span>
        <span className={over ? "font-medium text-ember" : "text-ink/60"}>
          {formatAmount(value, target.unit)} of {target.goal} {target.unit}
          {target.isLimit ? " limit" : ""}
        </span>
      </div>
      <div
        role="progressbar"
        aria-label={target.label}
        aria-valuemin={0}
        aria-valuemax={target.goal}
        aria-valuenow={Math.round(value)}
        className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-ink/10"
      >
        <div
          className={`h-full rounded-full transition-[width] duration-500 ${over ? "bg-ember" : "bg-leaf"}`}
          style={{ width: `${Math.min(percent, 100)}%` }}
        />
      </div>
    </div>
  );
}

function EntryRow({ entry, onRemove }: { entry: FoodEntry; onRemove: (id: string) => void }) {
  const [open, setOpen] = useState(false);
  const analysis = entry.ingredientAnalysis;
  const time = new Date(entry.loggedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

  return (
    <li className="py-4">
      <div className="flex items-start gap-2">
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          className="flex min-w-0 flex-1 items-start gap-4 rounded-lg text-left"
        >
          <span className="w-16 shrink-0 pt-0.5 text-sm text-ink/55">{time}</span>
          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <span className="font-medium">{entry.name}</span>
              {entry.brand && <span className="text-sm text-ink/55">{entry.brand}</span>}
              {entry.kind === "packaged" && analysis && (
                <span className="inline-flex items-center gap-1.5 rounded-full bg-ink/5 py-0.5 pl-2.5 pr-1 text-xs font-medium">
                  {analysis.ingredientCount} ingredients
                  <GradeBadge grade={analysis.grade} />
                </span>
              )}
              {entry.kind === "packaged" && !analysis && (
                <span className="rounded-full bg-ink/5 px-2.5 py-0.5 text-xs text-ink/60">No ingredient list</span>
              )}
            </span>
            <span className="block text-sm text-ink/60">{entry.quantityLabel}</span>
            <span className="mt-1 block text-sm">
              {Math.round(entry.macros.calories)} kcal · {Math.round(entry.macros.protein)}g protein ·{" "}
              {Math.round(entry.macros.carbs)}g carbs · {Math.round(entry.macros.fat)}g fat
            </span>
          </span>
        </button>
        <button
          type="button"
          onClick={() => onRemove(entry.id)}
          aria-label={`Remove ${entry.name}`}
          className="rounded-lg p-2 text-ink/40 hover:bg-ink/5 hover:text-ember"
        >
          <Trash2 className="h-4 w-4" aria-hidden />
        </button>
      </div>

      {open && (
        <div className="mt-4 space-y-4 pl-20">
          <dl className="grid grid-cols-2 gap-x-6 gap-y-1 text-sm sm:grid-cols-3">
            {MICRO_TARGETS.map((target) => (
              <div key={target.key} className="flex justify-between gap-2">
                <dt className="text-ink/60">{target.label}</dt>
                <dd className="font-medium">{formatAmount(entry.micros[target.key], target.unit)}</dd>
              </div>
            ))}
          </dl>
          <p className="text-xs text-ink/55">
            Source: {SOURCE_LABELS[entry.source]}
            {entry.matchedName ? ` · matched “${entry.matchedName}”` : ""}
          </p>
          {analysis && <IngredientCard analysis={analysis} />}
        </div>
      )}
    </li>
  );
}

interface DashboardProps {
  entries: FoodEntry[];
  ready: boolean;
  onRemove: (id: string) => void;
  onLoadDemo: () => void;
}

export function Dashboard({ entries, ready, onRemove, onLoadDemo }: DashboardProps) {
  const totals = useMemo(() => sumNutrition(entries), [entries]);
  const rings = MACRO_TARGETS.filter((target) => target.key !== "fiber");
  const fiber = MACRO_TARGETS.find((target) => target.key === "fiber");

  return (
    <div className="space-y-10 rounded-3xl bg-white/70 p-6 ring-1 ring-ink/10 sm:p-8">
      <section aria-labelledby="macros-heading">
        <h2 id="macros-heading" className="font-display text-2xl font-semibold">
          Macronutrients
        </h2>
        <div className="mt-5 grid grid-cols-2 gap-y-6 sm:grid-cols-4">
          {rings.map((target) => (
            <Ring key={target.key} target={target} value={totals.macros[target.key]} />
          ))}
        </div>
        {fiber && (
          <div className="mt-6">
            <Meter target={fiber} value={totals.macros.fiber} />
          </div>
        )}
      </section>

      <section aria-labelledby="micros-heading">
        <h2 id="micros-heading" className="font-display text-2xl font-semibold">
          Micronutrients
        </h2>
        <div className="mt-5 grid gap-x-10 gap-y-5 sm:grid-cols-2">
          {MICRO_TARGETS.map((target) => (
            <Meter key={target.key} target={target} value={totals.micros[target.key]} />
          ))}
        </div>
        <p className="mt-4 text-xs text-ink/55">
          Goals follow FDA Daily Values for a 2,000 calorie diet. Packaged labels often list only some micronutrients.
        </p>
      </section>

      <section aria-labelledby="log-heading">
        <div className="flex items-baseline justify-between">
          <h2 id="log-heading" className="font-display text-2xl font-semibold">
            Today’s log
          </h2>
          {entries.length > 0 && <span className="text-sm text-ink/60">{entries.length} items</span>}
        </div>

        {ready && entries.length === 0 ? (
          <div className="mt-4 rounded-2xl border border-dashed border-ink/20 p-8 text-center">
            <p className="font-medium">Nothing logged yet</p>
            <p className="mt-1 text-sm text-ink/60">Describe a meal, look up a packaged food, or scan a photo.</p>
            <button
              type="button"
              onClick={onLoadDemo}
              className="mt-4 inline-flex items-center gap-2 rounded-full bg-ink px-4 py-2 text-sm font-medium text-white hover:bg-ink/85"
            >
              <Sparkles className="h-4 w-4" aria-hidden /> Load demo data
            </button>
          </div>
        ) : (
          <ul className="mt-2 divide-y divide-ink/10">
            {entries.map((entry) => (
              <EntryRow key={entry.id} entry={entry} onRemove={onRemove} />
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
