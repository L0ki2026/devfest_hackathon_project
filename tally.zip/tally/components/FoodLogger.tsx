"use client";

import { useRef, useState, type FormEvent } from "react";
import { Camera, Loader2, Minus, PenLine, Plus, ScanBarcode, TriangleAlert, X } from "lucide-react";
import { IngredientCard } from "@/components/IngredientCard";
import { requestAnalysis } from "@/lib/client";
import { prepareImage } from "@/lib/image";
import { round, scaleFood } from "@/lib/nutrition";
import type { AnalyzeResponse, AnalyzedFood, ProductCandidate } from "@/types/nutrition";

const TABS = [
  { id: "meal", label: "Meal", icon: PenLine },
  { id: "packaged", label: "Packaged", icon: ScanBarcode },
  { id: "photo", label: "Photo", icon: Camera },
] as const;

type Tab = (typeof TABS)[number]["id"];

interface PendingFood {
  food: AnalyzedFood;
  servings: number;
}

const BARCODE_PATTERN = /^\d{8,14}$/;

const inputClass =
  "w-full rounded-xl border border-ink/15 bg-white px-3.5 py-2.5 text-sm placeholder:text-ink/40 focus:border-leaf";

const primaryButton =
  "inline-flex items-center justify-center gap-2 rounded-full bg-leaf px-5 py-2.5 text-sm font-medium text-white hover:bg-leaf/90 disabled:cursor-not-allowed disabled:opacity-60";

export function FoodLogger({ onAdd }: { onAdd: (foods: AnalyzedFood[]) => void }) {
  const [tab, setTab] = useState<Tab>("meal");
  const [mealText, setMealText] = useState("");
  const [productQuery, setProductQuery] = useState("");
  const [preview, setPreview] = useState<string | null>(null);
  const [candidates, setCandidates] = useState<ProductCandidate[]>([]);
  const [pending, setPending] = useState<PendingFood[]>([]);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  async function run(task: () => Promise<AnalyzeResponse>) {
    setLoading(true);
    setError(null);
    setWarnings([]);
    setCandidates([]);
    setPending([]);
    try {
      const result = await task();
      setWarnings(result.warnings);
      setCandidates(result.candidates);
      setPending(result.foods.map((food) => ({ food, servings: 1 })));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Something went wrong. Try again.");
    } finally {
      setLoading(false);
    }
  }

  function submitMeal(event: FormEvent) {
    event.preventDefault();
    if (!mealText.trim()) {
      setError("Describe what you ate first, for example “2 eggs and a slice of toast”.");
      return;
    }
    void run(() => requestAnalysis({ mode: "meal", text: mealText }));
  }

  function submitPackaged(event: FormEvent) {
    event.preventDefault();
    const query = productQuery.trim();
    if (!query) {
      setError("Enter a product name or a barcode.");
      return;
    }
    const digits = query.replace(/\s+/g, "");
    void run(() =>
      BARCODE_PATTERN.test(digits)
        ? requestAnalysis({ mode: "barcode", barcode: digits })
        : requestAnalysis({ mode: "search", query }),
    );
  }

  function pickCandidate(candidate: ProductCandidate) {
    void run(() => requestAnalysis({ mode: "barcode", barcode: candidate.barcode }));
  }

  function handleFile(file: File | undefined) {
    if (!file) return;
    void run(async () => {
      try {
        const image = await prepareImage(file);
        setPreview(image.previewUrl);
        return await requestAnalysis({ mode: "image", imageBase64: image.base64, mimeType: image.mimeType });
      } finally {
        if (fileRef.current) fileRef.current.value = "";
      }
    });
  }

  function changeServings(index: number, delta: number) {
    setPending((items) =>
      items.map((item, position) =>
        position === index ? { ...item, servings: Math.min(20, Math.max(0.5, round(item.servings + delta, 1))) } : item,
      ),
    );
  }

  function removePending(index: number) {
    setPending((items) => items.filter((_, position) => position !== index));
  }

  function discard() {
    setPending([]);
    setWarnings([]);
    setPreview(null);
  }

  function confirm() {
    onAdd(pending.map((item) => scaleFood(item.food, item.servings)));
    discard();
    setMealText("");
    setProductQuery("");
    setCandidates([]);
  }

  function switchTab(next: Tab) {
    setTab(next);
    setError(null);
    setCandidates([]);
  }

  return (
    <div className="rounded-3xl bg-white/70 p-6 ring-1 ring-ink/10">
      <h2 className="font-display text-2xl font-semibold">Log food</h2>

      <div role="tablist" aria-label="Logging method" className="mt-4 grid grid-cols-3 gap-1 rounded-full bg-ink/5 p-1">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={tab === id}
            onClick={() => switchTab(id)}
            className={`inline-flex items-center justify-center gap-1.5 rounded-full px-3 py-2 text-sm font-medium ${
              tab === id ? "bg-white shadow-sm" : "text-ink/60 hover:text-ink"
            }`}
          >
            <Icon className="h-4 w-4" aria-hidden />
            {label}
          </button>
        ))}
      </div>

      <div className="mt-5">
        {tab === "meal" && (
          <form onSubmit={submitMeal} className="space-y-3">
            <label htmlFor="meal-text" className="text-sm font-medium">
              What did you eat?
            </label>
            <textarea
              id="meal-text"
              rows={3}
              value={mealText}
              onChange={(event) => setMealText(event.target.value)}
              placeholder="2 eggs, 1 slice sourdough toast, half an avocado"
              className={`${inputClass} resize-none`}
            />
            <button type="submit" disabled={loading} className={primaryButton}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
              {loading ? "Analyzing meal" : "Analyze meal"}
            </button>
          </form>
        )}

        {tab === "packaged" && (
          <form onSubmit={submitPackaged} className="space-y-3">
            <label htmlFor="product-query" className="text-sm font-medium">
              Product name or UPC barcode
            </label>
            <input
              id="product-query"
              value={productQuery}
              onChange={(event) => setProductQuery(event.target.value)}
              placeholder="Greek yogurt, or 737628064502"
              inputMode="search"
              className={inputClass}
            />
            <button type="submit" disabled={loading} className={primaryButton}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
              {loading ? "Looking up" : "Look up product"}
            </button>
          </form>
        )}

        {tab === "photo" && (
          <div className="space-y-3">
            <p className="text-sm text-ink/70">
              Upload a photo of a meal, or of a package’s Nutrition Facts and ingredients.
            </p>
            <input
              ref={fileRef}
              id="photo-input"
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(event) => handleFile(event.target.files?.[0])}
            />
            <label
              htmlFor="photo-input"
              className={`${primaryButton} cursor-pointer ${loading ? "pointer-events-none opacity-60" : ""}`}
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Camera className="h-4 w-4" aria-hidden />}
              {loading ? "Reading photo" : "Choose a photo"}
            </label>
            {preview && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={preview} alt="Selected upload" className="max-h-48 rounded-xl border border-ink/10 object-cover" />
            )}
          </div>
        )}
      </div>

      <div aria-live="polite">
        {error && (
          <p role="alert" className="mt-4 flex gap-2 rounded-xl bg-ember/10 p-3 text-sm text-ember">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
            {error}
          </p>
        )}
        {warnings.map((warning) => (
          <p key={warning} className="mt-3 flex gap-2 rounded-xl bg-saffron/15 p-3 text-sm">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
            {warning}
          </p>
        ))}
      </div>

      {candidates.length > 0 && (
        <section aria-label="Matching products" className="mt-5 border-t border-ink/10 pt-4">
          <h3 className="text-sm font-semibold">Choose the product</h3>
          <ul className="mt-2 space-y-1">
            {candidates.map((candidate) => (
              <li key={candidate.barcode}>
                <button
                  type="button"
                  onClick={() => pickCandidate(candidate)}
                  disabled={loading}
                  className="flex w-full items-center gap-3 rounded-xl p-2 text-left hover:bg-ink/5 disabled:opacity-60"
                >
                  {candidate.imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={candidate.imageUrl} alt="" className="h-10 w-10 rounded-md bg-white object-contain" />
                  ) : (
                    <span className="h-10 w-10 rounded-md bg-ink/5" aria-hidden />
                  )}
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-medium">{candidate.name}</span>
                    <span className="block truncate text-xs text-ink/60">
                      {candidate.brand ? `${candidate.brand} · ` : ""}
                      {candidate.barcode}
                    </span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {pending.length > 0 && (
        <section aria-label="Review before logging" className="mt-6 border-t border-ink/10 pt-5">
          <h3 className="font-display text-lg font-semibold">Review</h3>
          <ul className="mt-3 space-y-5">
            {pending.map((item, index) => {
              const scaled = scaleFood(item.food, item.servings);
              return (
                <li key={`${item.food.name}-${index}`} className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-medium">{item.food.name}</p>
                      <p className="text-sm text-ink/60">{item.food.quantityLabel}</p>
                      <p className="mt-1 text-sm">
                        {Math.round(scaled.macros.calories)} kcal · {Math.round(scaled.macros.protein)}g protein ·{" "}
                        {Math.round(scaled.macros.carbs)}g carbs · {Math.round(scaled.macros.fat)}g fat
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => removePending(index)}
                      aria-label={`Remove ${item.food.name} from review`}
                      className="rounded-lg p-1.5 text-ink/40 hover:bg-ink/5 hover:text-ember"
                    >
                      <X className="h-4 w-4" aria-hidden />
                    </button>
                  </div>

                  <div className="flex items-center gap-3 text-sm">
                    <span className="text-ink/60">Portions</span>
                    <div className="inline-flex items-center rounded-full border border-ink/15 bg-white">
                      <button
                        type="button"
                        onClick={() => changeServings(index, -0.5)}
                        aria-label="Decrease portions"
                        className="rounded-full p-2 hover:bg-ink/5"
                      >
                        <Minus className="h-3.5 w-3.5" aria-hidden />
                      </button>
                      <span className="w-10 text-center font-medium tabular-nums">{item.servings}</span>
                      <button
                        type="button"
                        onClick={() => changeServings(index, 0.5)}
                        aria-label="Increase portions"
                        className="rounded-full p-2 hover:bg-ink/5"
                      >
                        <Plus className="h-3.5 w-3.5" aria-hidden />
                      </button>
                    </div>
                  </div>

                  {item.food.ingredientAnalysis && <IngredientCard analysis={item.food.ingredientAnalysis} />}
                </li>
              );
            })}
          </ul>
          <div className="mt-5 flex gap-2">
            <button type="button" onClick={confirm} className={primaryButton}>
              Add to today’s log
            </button>
            <button
              type="button"
              onClick={discard}
              className="rounded-full px-4 py-2.5 text-sm font-medium text-ink/70 hover:bg-ink/5"
            >
              Discard
            </button>
          </div>
        </section>
      )}
    </div>
  );
}
